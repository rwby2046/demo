package com.example.provider01.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.provider01.service.TestService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author wdx
 * @date 2022/7/6 23:16
 * @description:
 **/
@Slf4j
@Service
public class TestServiceImpl implements TestService {

    @Autowired
    private AsyncService asyncService;

    @Override
    public String query() {

        try {
            Thread.sleep(500);
        } catch (Exception e) {
            log.info("sadadadasd");
        }

        long time = System.currentTimeMillis();
        asyncService.asyncWrite();
        log.info("async task cost time = {}", System.currentTimeMillis() - time);

        return "success";
    }
}
