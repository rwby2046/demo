package com.example.provider01.service.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.example.provider01.entity.User;
import com.example.provider01.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AsyncService {

    @Autowired
    private UserService userService;

    @Async("myExecutor")
    public void asyncWrite() {
        User user = new User();
        user.setName("王铁柱");
        user.setUsername("王铁柱");
        user.setBirthday(new Date());
        user.setAddress("1");
        user.setPassword("1");
        user.setStatus(1);
        user.setAge(30);
        user.setSex("男");
        userService.insert(user);
        log.info("add user success");
    }

}
