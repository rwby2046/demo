package com.example.provider01.config;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import lombok.Data;

@Configuration
@Data
public class ExecutorConfig {

    /**
     * 核心线程
     */
    private int corePoolSize = 3;

    /**
     * 最大线程
     */
    private int maxPoolSize = 6;

    /**
     * 队列容量
     */
    private int queueCapacity = 1000;

    /**
     * 保持时间
     */
    private int keepAliveSeconds = 300;

    /**
     * 名称前缀
     */
    private String preFix = "name";

    @Bean
    public Executor myExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(corePoolSize);
        executor.setMaxPoolSize(maxPoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setKeepAliveSeconds(keepAliveSeconds);
        executor.setThreadNamePrefix(preFix);
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
        executor.initialize();
        return executor;
    }
}