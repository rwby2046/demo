package com.example.provider01.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.ToString;

/**
 * (User)实体类
 *
 * @author makejava
 * @since 2021-09-12 14:19:28
 */
@Data
@ToString
public class User implements Serializable {
    private static final long serialVersionUID = -70615843483805749L;

    private Integer id;
    /**
     * 用户名称
     */
    private String username;
    /**
     * 生日
     */
    private Date birthday;
    /**
     * 性别
     */
    private String sex;
    /**
     * 地址
     */
    private String address;

    private String name;

    private String password;

    private Integer age;

    private Integer status;
}
