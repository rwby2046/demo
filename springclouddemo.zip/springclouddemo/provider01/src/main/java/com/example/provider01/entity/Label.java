package com.example.provider01.entity;

import java.io.Serializable;
import java.util.List;

import lombok.Data;
import lombok.ToString;

/**
 * (User)实体类
 *
 * @author makejava
 * @since 2021-09-12 14:19:28
 */
@Data
@ToString
public class Label implements Serializable {
    private static final long serialVersionUID = -70615843483805749L;

    private Integer id;

    private String name;

    private Integer parentId;

    private Integer level;

    private List<Label> subLabels;
}
