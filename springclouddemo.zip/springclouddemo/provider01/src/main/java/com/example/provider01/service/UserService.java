package com.example.provider01.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import com.example.provider01.entity.User;

/**
 * (User)表服务接口
 *
 * @author makejava
 * @since 2021-09-12 14:19:29
 */
public interface UserService {

    /**
     * 通过ID查询单条数据
     *
     * @param id
     *            主键
     * @return 实例对象
     */
    User queryById(Integer id);

    /**
     * 分页查询
     *
     * @param user
     *            筛选条件
     * @param pageRequest
     *            分页对象
     * @return 查询结果
     */
    Page<User> queryByPage(User user, PageRequest pageRequest);

    /**
     * 新增数据
     *
     * @param user
     *            user
     * @return user
     */
    User insert(User user);

    /**
     * 修改数据
     *
     * @param user
     *            user
     * @return user
     */
    User update(User user);

    /**
     * 通过主键删除数据
     *
     * @param id
     *            id
     * @return 是否成功
     */
    boolean deleteById(Integer id);

    List<User> list();

    List<String> queryByStatus(Integer status, Integer start, Integer length);

    List<String> queryList(Integer length);

}
