package com.example.provider01.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.provider01.dao.UserDao;
import com.example.provider01.entity.User;
import com.example.provider01.service.UserService;
import com.example.provider01.util.PageBean;

/**
 * (User)表服务实现类
 *
 * @author makejava
 * @since 2021-09-12 14:19:30
 */
@Service("userService")
public class UserServiceImpl implements UserService {
    @Resource
    private UserDao userDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id
     *            主键
     * @return 实例对象
     */
    @Override
    public User queryById(Integer id) {
        return userDao.queryById(id);
    }

    /**
     * 分页查询
     *
     * @param user
     *            筛选条件
     * @param pageRequest
     *            分页对象
     * @return 查询结果
     */
    @Override
    public Page<User> queryByPage(User user, PageRequest pageRequest) {
        long total = userDao.count(user);
        return new PageImpl<>(userDao.queryAllByLimit(user, pageRequest), pageRequest, total);
    }

    /**
     * 新增数据
     *
     * @param user
     *            实例对象
     * @return 实例对象
     */
    @Override
    public User insert(User user) {
        userDao.insert(user);
        return user;
    }

    /**
     * 修改数据
     *
     * @param user
     *            实例对象
     * @return 实例对象
     */
    @Override
    public User update(User user) {
        userDao.update(user);
        return queryById(user.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id
     *            主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Integer id) {
        return userDao.deleteById(id) > 0;
    }

    @Override
    public List<User> list() {
        return userDao.list();
    }

    @Override
    public List<String> queryByStatus(Integer status, Integer start, Integer length) {
        // 查询符合条件的总记录数
        Integer totalRows = userDao.queryCount(status);
        // 定义分页对像
        PageBean<String> pageBean = new PageBean<>(start, length, totalRows);
        // 查询返回的指定记录数
        return userDao.queryUserName(status, start, length);
    }

    @Override
    public List<String> queryList(Integer length) {

        return userDao.queryList(length);
    }

}
