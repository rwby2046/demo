package com.example.provider01.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.example.provider01.bo.ResultData;
import com.example.provider01.dao.LabelDao;
import com.example.provider01.entity.Label;
import com.example.provider01.entity.QueryLabelReqVo;
import com.example.provider01.service.LabelService;

import lombok.extern.slf4j.Slf4j;

/**
 * @author wdx
 * @description: 标签管理
 **/
@Slf4j
@Service
public class LabelServiceImpl implements LabelService {

    @Resource
    private LabelDao labelDao;

    /**
     * 查询标签树
     *
     * 新建标签和所述标签 只展示二级树，传name和level搜索
     *
     * @param req
     * @return
     */
    @Override
    public ResultData<List<Label>> queryTree(QueryLabelReqVo req) {
        String name = req.getName();
        Integer parentId = req.getParentId();
        Integer level = req.getLevel();
        // 1.默认展示一级标签
        if (StringUtils.isEmpty(name) && parentId == null) {
            List<Label> labels = labelDao.queryByParentId(0);
            return ResultData.success(labels);
        }
        // 2.传parentId,根据父级id查询子标签
        if (StringUtils.isEmpty(name) && parentId != null) {
            List<Label> labels = labelDao.queryByParentId(parentId);
            return ResultData.success(labels);
        }
        // 3.根据标签名称查询标签  递归查询
        // todo 是否模糊查询
        if (StringUtils.isNotEmpty(name) && parentId == null) {
            Label labelReq = new Label();
            labelReq.setName(name);
            labelReq.setLevel(level);
            List<Label> labels = labelDao.queryUp(labelReq);
            if (labels.isEmpty()) {
                return ResultData.success(new ArrayList<>());
            }
            // 不为空，将list转成树状结构返回
            List<Label> collect = new ArrayList<>();
            for (Label label : labels) {
                if (label.getParentId() == 0) {
                    label.setSubLabels(getChildren(label, labels));
                    collect.add(label);
                }
            }
            return ResultData.success(collect);
        }








//        if (StringUtils.isNotEmpty(name)) {
//            Label query = labelDao.query(label);
//            Integer pid = query.getParentId();
//            if (pid != null) {
//                label = new Label();
//                label.setId(pid);
//                Label pLabel = labelDao.query(label);
//                List<Label> subLabels = new ArrayList<>();
//                subLabels.add(query);
//                pLabel.setSubLabels(subLabels);
//                List<Label> labels = new ArrayList<>();
//                labels.add(pLabel);
//                return ResultData.success(labels);
//            }
//        } else {
//            List<Label> labels = labelDao.queryTree(label);
//        }
        return null;
    }

    /**
     * 递归查询子节点
     * @param root  根节点
     * @param labelList  所有节点
     * @return 根节点信息
     */
    private List<Label> getChildren(Label root, List<Label> labelList) {
        return labelList.stream().filter(m -> {
            return Objects.equals(m.getParentId(), root.getId());
        }).map(
                (m) -> {
                    m.setSubLabels(getChildren(m, labelList));
                    return m;
                }
        ).collect(Collectors.toList());
    }

    @Override
    public ResultData<List<Label>> queryByParentId(Integer parentId) {
        if (parentId == null) {
            return ResultData.fail(500, "parentId can not be null");
        }
        List<Label> labels = labelDao.queryByParentId(parentId);
        return ResultData.success(labels);
    }

    @Override
    public List<Label> queryList(QueryLabelReqVo req) {
        // 一级标签页默认展示第一级所有标签
        if (req.getParentId() == null && req.getLevel() == 1) {
            return labelDao.queryByParentId(0);
        }
        // 二级标签页默认展示三级标签
        if (req.getLevel() == 3) {
            Label label = new Label();
            List<Label> labels = labelDao.queryByPage(label);

            List<Integer> collect = labels.stream().map(Label::getParentId).collect(Collectors.toList());

            List<Label> names = labelDao.queryName(collect);

            return null;
        }



        return null;
    }
}
