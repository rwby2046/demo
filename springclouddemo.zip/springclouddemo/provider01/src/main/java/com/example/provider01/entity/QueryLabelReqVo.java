package com.example.provider01.entity;

import java.io.Serializable;


import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.ToString;

/**
 * (User)实体类
 *
 * @author makejava
 * @since 2021-09-12 14:19:28
 */
@Data
@ToString
public class QueryLabelReqVo implements Serializable {
    private static final long serialVersionUID = -70615843483805749L;

    private String name;

    private Integer parentId;

    @NotNull(message = "level 不能为空")
    @Size(max = 3, min = 1)
    private Integer level;
}
