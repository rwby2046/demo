package com.example.provider01.util;

import java.util.List;

/**
 * 分页类封装
 * <p>
 * Created by 16080536 on 2017/6/10.
 */
public class PageBean<T> {
    private int totalRows;// how many rows
    private int currentPage;// the index of page now
    private int totalPages;// how many pages
    private int pageSize;// how many rows in each page
    private List<T> list;// the data need to show at current page
    // feign反序列化使用。

    public PageBean() {}

    /**
     * @param currentPage
     *            the index of page now
     * @param pageSize
     *            how many rows in each page
     * @param totalRows
     *            how many pages
     */
    public PageBean(int currentPage, int pageSize, int totalRows) {
        if (currentPage < 1) {
            currentPage = 0;
        }
        this.currentPage = currentPage;
        this.pageSize = pageSize;
        this.totalRows = totalRows;
        totalPages = (int)Math.ceil(totalRows / (double)pageSize);
    }

    /**
     * Whether there is next page
     *
     * @return
     */
    public synchronized boolean hasNextPage() {
        boolean result = false;
        if (currentPage < totalPages) {
            result = true;
        }
        return result;
    }

    /**
     * Whether there is previous page
     *
     * @return
     */
    public synchronized boolean hasPreviousPage() {
        boolean boo = false;
        if (currentPage > 1) {
            boo = true;
        }
        return boo;
    }

    /**
     * Get the data list you need to show in current page(after invoke the method setList)
     *
     * @return
     */
    public synchronized List<T> getList() {
        return list;
    }

    /**
     * set the data list you need to show in current page
     *
     * @param list
     */
    public synchronized void setList(List<T> list) {
        this.list = list;
    }

    /**
     * get the index of current page
     *
     * @return
     */
    public synchronized int getCurrentPage() {
        return currentPage;
    }

    /**
     * how many pages
     *
     * @return
     */
    public synchronized int getTotalPages() {

        return totalPages;
    }

    /**
     * how many rows in a page
     *
     * @return
     */
    public synchronized int getPageSize() {
        return pageSize;
    }

    /**
     * all rows
     *
     * @return
     */
    public synchronized int getTotalRows() {
        return totalRows;
    }

    /**
     * the index of start row
     *
     * @return
     */
    public synchronized int getStartRow() {
        return ((currentPage - 1) * pageSize);
    }
}
