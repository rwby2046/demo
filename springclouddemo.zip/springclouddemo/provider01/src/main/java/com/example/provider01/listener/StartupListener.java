package com.example.provider01.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.example.provider01.util.SpringUtil;

/**
 * @description: 系统启动监听器
 */
@Component
public class StartupListener extends ContextLoaderListener {

    private static final Logger logger = LoggerFactory.getLogger(StartupListener.class);

    @Override
    public void contextInitialized(ServletContextEvent event) {
        logger.info("加载系统启动项...");
        logger.info("start to load startup listener  ........");
        // 获取Servlet上下文
        ServletContext sct = event.getServletContext();
        // 获取Spring应用上下文
        ApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(sct);
        // 静态常量持有Spring上下文
        logger.info("init SpringUtil...");
        SpringUtil.initial(sct, ctx);

        // 将表中数据写入redis
        logger.info("start load ...");
        // RedisServiceImpl serviceBean = SpringUtil.getServiceBean(RedisServiceImpl.class);
        // if (serviceBean != null) {
        // serviceBean.sayHi();
        // }

        logger.info("end load ...");

        logger.info("load startup listener succeed!");
        logger.info("加载系统启动项结束!");
    }

    @Override
    public void contextDestroyed(ServletContextEvent event) {
        logger.info("contextDestroyed start ...");
        logger.info("start destroyed faceSearchNative...");

        logger.info("contextDestroyed finish ...");

    }
}
