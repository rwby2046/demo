package com.example.provider01.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.provider01.bo.ResultData;
import com.example.provider01.bo.ReturnCode;
import com.example.provider01.entity.User;
import com.example.provider01.service.UserService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import lombok.extern.slf4j.Slf4j;

/**
 * @author wdx
 * @date 2022/4/9 19:28
 * @description
 **/
@RestController
@RequestMapping("/user")
@Slf4j
public class UserController {

    @HystrixCommand(fallbackMethod = "paymentCircuitBreaker_fallback")
    @RequestMapping("/pay")
    public String paymentCircuitBreaker(@RequestParam("id") Integer id) throws InterruptedException {

        if (id < 0) {
            throw new NullPointerException("******id 不能负数");
        }

        // Thread.sleep(100);

        String serialNumber = UUID.randomUUID().toString();
        return Thread.currentThread().getName() + "\t" + "调用成功,流水号: " + serialNumber;
    }

    public String paymentCircuitBreaker_fallback(@RequestParam("id") Integer id) {
        log.info("------熔断-----" + LocalDateTime.now());
        return "id 不能负数,请稍后再试,id: " + id;
    }

    @Value("${server.port}")
    String port;

    @Resource
    private UserService userService;

    @HystrixCommand(defaultFallback = "queryByIdFallback")
    @GetMapping("/queryById")
    public ResultData<User> queryById(@RequestParam Integer id) {

        int num = new Random().nextInt(10);
        log.info("num==" + num);
        if (num % 2 == 0) {
            throw new NullPointerException("");
        }

        return ResultData.success(userService.queryById(id));
    }

    public ResultData<User> queryByIdFallback() {
        User user = new User();
        user.setAddress("fail");
        log.info("------熔断-----" + LocalDateTime.now());
        return ResultData.fail(ReturnCode.RC201.getCode(), ReturnCode.RC201.getMessage());
    }

    @RequestMapping("/hi")
    public String home(@RequestParam String name) {
        return "hi " + name + ",i am from port:" + port;
    }

    @GetMapping("/list")
    public ResponseEntity<List<User>> list() {
        return ResponseEntity.ok(userService.list());
    }

    /**
     * 新增数据
     *
     * @param user
     *            实体
     * @return 新增结果
     */
    @PostMapping("/add")
    public ResponseEntity<User> add(User user) {
        User insert = userService.insert(user);
        return ResponseEntity.ok(insert);
    }

    /**
     * 编辑数据
     *
     * @param user
     *            实体
     * @return 编辑结果
     */
    @PutMapping("/edit")
    public ResponseEntity<User> edit(User user) {
        return ResponseEntity.ok(userService.update(user));
    }

    /**
     * 删除数据
     *
     * @param id
     *            主键
     * @return 删除是否成功
     */
    @DeleteMapping("/deleteById")
    public ResponseEntity<Boolean> deleteById(Integer id) {
        return ResponseEntity.ok(userService.deleteById(id));
    }

    @GetMapping("/queryByStatus")
    public ResponseEntity<List<String>> queryByStatus(@RequestParam Integer status, Integer start, Integer length) {
        return ResponseEntity.ok(userService.queryByStatus(status, start, length));
    }

    @PostMapping("/queryAllUsers")
    public ResponseEntity<Page<User>> queryAllUsers(@RequestParam User user, PageRequest pageRequest) {
        return ResponseEntity.ok(userService.queryByPage(user, pageRequest));
    }

    @GetMapping("/queryList")
    public ResponseEntity<List<String>> queryList(@RequestParam Integer length) {
        return ResponseEntity.ok(userService.queryList(length));
    }
}
