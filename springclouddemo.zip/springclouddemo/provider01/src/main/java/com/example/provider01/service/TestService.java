package com.example.provider01.service;

/**
 * @author wdx
 * @date 2022/7/6 23:16
 * @description
 **/
public interface TestService {

    String query();

}
