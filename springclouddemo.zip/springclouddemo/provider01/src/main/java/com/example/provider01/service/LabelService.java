package com.example.provider01.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example.provider01.bo.ResultData;
import com.example.provider01.entity.Label;
import com.example.provider01.entity.QueryLabelReqVo;
import com.example.provider01.entity.User;

public interface LabelService {

    ResultData<List<Label>> queryTree(QueryLabelReqVo req);

    ResultData<List<Label>> queryByParentId(Integer parentId);

    List<Label> queryList(QueryLabelReqVo req);
}
