// package com.example.provider01.task;
//
// import javax.annotation.Resource;
//
// import org.springframework.context.annotation.Configuration;
// import org.springframework.scheduling.annotation.EnableScheduling;
// import org.springframework.scheduling.annotation.SchedulingConfigurer;
// import org.springframework.scheduling.config.ScheduledTaskRegistrar;
//
// import com.example.provider01.dao.UserDao;
//
// import lombok.extern.slf4j.Slf4j;
//
/// ***
// *
// * @author wqn
// */
// @Slf4j
// @Configuration
// @EnableScheduling
// public class DynamicScheduleTask implements SchedulingConfigurer {
// @Resource
// private UserDao userDao;
//
// /**
// * 执行定时任务.
// */
// @Override
// public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
//
// String cron = "*/5 * * * * ?";
// taskRegistrar.addCronTask(() -> userDao.deleteByStatus(-1), cron);
// }
// }