package com.example.provider01.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.provider01.bo.ResultData;
import com.example.provider01.entity.Label;
import com.example.provider01.entity.QueryLabelReqVo;
import com.example.provider01.service.LabelService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/label-mng")
@Slf4j
public class LabelController {

    @Resource
    private LabelService labelService;

    @PostMapping("/queryTree")
    public ResultData<List<Label>>query(@RequestBody QueryLabelReqVo req) {
        return labelService.queryTree(req);
    }

    @PostMapping("/queryList")
    public ResponseEntity<List<Label>> queryList(@RequestBody QueryLabelReqVo req) {
        List<Label> labels = labelService.queryList(req);
        return ResponseEntity.ok(labels);
    }

    @GetMapping("/queryByParentId")
    public ResultData<List<Label>> query(@RequestParam Integer parentId) {
        return labelService.queryByParentId(parentId);
    }
}