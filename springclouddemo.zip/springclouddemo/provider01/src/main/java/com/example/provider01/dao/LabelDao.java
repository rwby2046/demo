package com.example.provider01.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.provider01.entity.Label;

/**
 * (User)表数据库访问层
 *
 * @author makejava
 * @since 2021-09-12 14:19:27
 */
@Mapper
public interface LabelDao {


    List<Label> queryTree(@Param("label") Label label);

    Label query(@Param("label") Label label);

    List<Label> queryByParentId(@Param("parentId") Integer parentId);


    List<Label> queryUp(@Param("label") Label label);

    List<Label> queryByPage(@Param("label") Label label);

    List<Label> queryName(List<Integer> ids);
}
